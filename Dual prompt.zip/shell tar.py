import os
import tarfile

def extract_tar_files(source_dir, target_dir):
    # 确保目标文件夹存在，如果不存在则创建
    if not os.path.exists(target_dir):
        os.makedirs(target_dir)

    # 遍历源文件夹中的所有文件
    for filename in os.listdir(source_dir):
        # 检查文件是否以 .tar 结尾
        if filename.endswith(".tar"):
            # 构建源文件的完整路径
            source_file = os.path.join(source_dir, filename)

            # 打开 .tar 文件并解压
            with tarfile.open(source_file, 'r') as tar:
                # 解压到目标文件夹
                tar.extractall(path=target_dir)
                print(f"Extracted: {source_file} -> {target_dir}")

if __name__ == "__main__":
    # 设置源文件夹和目标文件夹路径
    source_directory = "E:\迅雷下载"  # 替换为你的源文件夹路径
    target_directory = "E:\imagenet-c"  # 替换为你的目标文件夹路径

    # 调用函数解压文件
    extract_tar_files(source_directory, target_directory)