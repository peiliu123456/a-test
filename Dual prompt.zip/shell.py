import subprocess

# 定义要执行的命令
commands = [
    "python main.py --method ours --lr 1e-3 --prompt_lr 5e-4 --mask_rate 0.02",
   # "python main.py --method tent",
   # "python main.py --method sar",
   # "python main.py --method dct"
]

# 依次执行每个命令
for command in commands:
    print(f"Running command: {command}")
    try:
        # 使用 subprocess.run 执行命令，并等待命令执行完
        result = subprocess.run(command, shell=True, check=True, text=True, stdout=subprocess.PIPE,
                                stderr=subprocess.PIPE)

        # 打印命令的输出和错误信息
        print(f"Output of command:\n{result.stdout}")
        print(f"Error of command:\n{result.stderr}")
    except subprocess.CalledProcessError as e:
        # 如果命令执行失败，捕获异常并打印错误信息
        print(f"Command failed with error:\n{e.stderr}")
